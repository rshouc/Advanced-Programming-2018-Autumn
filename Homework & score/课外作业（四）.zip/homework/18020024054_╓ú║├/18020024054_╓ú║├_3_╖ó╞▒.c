#include<stdio.h>
int main()
{
 int i, j, id, n;
 double person[3] = {};
 double type[3] = {};
 char ch;
 double money;
  for(i = 0; i < 3; ++i) {
   scanf("%d", &id);
   scanf("%d", &n);
    for(j = 0; j < n; ++j) {
      getchar();
      scanf("%c%lf", &ch, &money);
    if(id == 1)
     person[0]=money+person[0];
    else if(id == 2)
     person[1]=money+person[1];
    else if(id == 3)
     person[2]=money+person[2];
    if(ch == 'A')
     type[0]=money+type[0];
    else if(ch == 'B')
     type[1]=money+type[1];
    else if(ch == 'C')
     type[2]=money+type[2];
     }
    }
for(i = 1; i <= 3; ++i)
printf("%d %.2f\n", i, person[i - 1]);
for(ch = 'A'; ch <= 'C'; ++ch)
printf("%c %.2f\n", ch, type[ch - 'A']);
	system("pause");
	return 0;
}
