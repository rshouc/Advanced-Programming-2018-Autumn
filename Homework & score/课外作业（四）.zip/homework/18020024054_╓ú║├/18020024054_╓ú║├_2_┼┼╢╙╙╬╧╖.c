#include <stdio.h>
#include <stdlib.h>
int main()
{
	char a[99];
    int b[99],c[99],i,j=0,k,g,m;
    gets(a);
    m=strlen(a);
    if(m%2==0){
      for(i=0;i<=m-1;i++){
        if(a[i]!=a[0]){
          b[j]=i;
          c[j]=i-1;
          for(k=i-1;k>=0;k--){
            for(g=j-1;g>=0;g--){
              if(a[c[j]]!=a[0]||c[j]==c[g])
            c[j]=c[j]-1;
            }
          }          
          j++;
        }
      }
      }
      for(j=0;j<=m/2-1;j++){
      printf("%d %d\n",c[j],b[j]);
    }
	system("pause");
	return 0;
}
