#include<stdio.h>
int main()
{
    int i,j,k,row,col;
    while(scanf("%d %d",&row,&col)!=EOF)
    {
        int a[row][col];
        for(i=0; i<row; i++)
        {
            for(j=0; j<col; j++)
            {
                scanf("%d",&a[i][j]);
            }
        }
        for(k=0; k<=row+col; k++)
           {
            for(i=0; i<row; i++)
               {
                for(j=0; j<col; j++)
                   {
                    if(i+j==k)
                    {
                        printf("%d\n",a[i][j]);
                    }
                   }
               }
           }
    
    }
	system("pause");
	return 0;
}
