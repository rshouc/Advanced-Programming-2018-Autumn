#include <stdio.h>
#include <stdlib.h>

int main()
{
    char a[100];
    int kid[100];
    int i,j;
    int num;
    int n=1;
    int num1[100],num2[100];
    int p=0;
    int temp1,temp2;
    scanf("%s",a);
    for(i=0;a[i]!='\0';i++)
    {
        if(a[i]==a[0])  kid[i]=1;
        else            kid[i]=0;
    }
    num=i;
    while(n<=num/2)
    {
    for(i=0;i<num;i++)
    {
        if(kid[i]==1)
        {
            for(j=i+1;j<num;j++)
            {
                if(kid[j]==1)  break;
                if(kid[j]==0)
                {
                    //printf("%d %d\n",i,j);
                    num1[p]=i;
                    num2[p]=j;
                    //printf("%d %d\n",num1[p],num2[p]);
                    kid[j]=2;
                    kid[i]=2;
                    n++;
                    p++;
                    break;
                }
                if(kid[j]==2) continue;
            }

        }
    }
    }
    //printf("%d",number);
    for(i=0;i<(num/2)-1;i++)
        for(j=0;j<(num/2)-1-i;j++)
    {
        if(num2[j]>num2[j+1])
        {
            temp2=num2[j];
            num2[j]=num2[j+1];
            num2[j+1]=temp2;

            temp1=num1[j];
            num1[j]=num1[j+1];
            num1[j+1]=temp1;

        }
    }
    for(p=0;p<num/2;p++)
    {
        printf("%d %d\n",num1[p],num2[p]);
    }
    return 0;
}

