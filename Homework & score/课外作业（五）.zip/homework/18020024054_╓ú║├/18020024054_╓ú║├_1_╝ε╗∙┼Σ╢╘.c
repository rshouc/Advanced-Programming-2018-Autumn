#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main()
{
    int n,i,j,num;
    char str[255]={0};
    scanf("%d",&n);
    
 for(j=0;j<n+1;j++)
{
   
   gets(str);
   num=strlen(str);
    
   for(i=0;i<num;i++)
   {
      if(str[i]=='A')
      {
      printf("T");
      }   
    
      if(str[i]=='T')
      {
      printf("A");
      }   
    
      if(str[i]=='C')
      {
      printf("G");
      }   
   
      if(str[i]=='G')
      {
      printf("C");
      }
     if(i==num-1)
     {
      printf("\n");      
     }
   } 
      
 }
 
	system("pause");
	return 0;
}
