#include<stdio.h>
struct student
  {
  int num,score[3];
  float aver;
  }
stu[10];
void main()
 {
    int i,j;
    struct student temp;                                        
    for(i=0;i<10;i++)
    {
    scanf("%d",&stu[i].num);
    scanf("%d %d %d",&stu[i].score[0],&stu[i].score[1],&stu[i].score[2]);
    } 
 
for(i=0;i<10;i++)
  {
int sum=0;
for(j=0;j<3;j++)
   {
   sum+=stu[i].score[j];
   stu[i].aver=sum/3.0;
   }
  }
for(i=0;i<9;i++)                                             
   {
    for(j=0;j<9-i;j++)
      {
       if(stu[j].aver>stu[j+1].aver)
         {
          temp=stu[j];                                              
          stu[j]=stu[j+1];
          stu[j+1]=temp;
         }
      }
    }
for(i=9;i>=0;i--)
  {
  printf("%d-",stu[i].num);
   for(j=0;j<3;j++)
     {
      printf("%d-",stu[i].score[j]);
     }
      printf("%.2f\n",stu[i].aver);
    }



	system("pause");
	return 0;
}
