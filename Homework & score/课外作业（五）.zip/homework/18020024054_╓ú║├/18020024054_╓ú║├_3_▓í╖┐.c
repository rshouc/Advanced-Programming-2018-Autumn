#include <stdio.h>
#include <stdlib.h>
int main()
{
    int i,a[999], p[999],n,t=0,len;    
    float b[999],q[999],deadline;
    scanf("%d %f",&n,&deadline);
    for(i=0;i<n;i++)
    scanf("%d %f",&a[i],&b[i]);
    for(i=0;i<n;i++){
      if(b[i]>=deadline){
      p[t]=a[i];
      q[t]=b[i];
      t++;
      }
    }
if(t==0)
printf("None.");
else{
     int j, temp;
    for (j = 0; j < t - 1; j++){
        for (i = 0; i < t - 1 - j; i++)
        {
            if(q[i] <q[i + 1])
            {
                temp = q[i];
                q[i] = q[i + 1];
                q[i + 1] = temp;
                temp = p[i];
                p[i] = p[i + 1];
                p[i + 1] = temp;
            }
        }
    }
    for(i=0;i<t;i++)
    printf("%03d %.1f\n",p[i],q[i]);
}
	system("pause");
	return 0;
}
