#include <stdio.h>
int main()
{    
    int K;
    scanf("%d",&K);
    int x=K/100;
    int y=K/10%10;
    int z=K%10;
    printf("%d\n",x);
    printf("%d\n",y);
    printf("%d\n",z);
	return 0;
}
