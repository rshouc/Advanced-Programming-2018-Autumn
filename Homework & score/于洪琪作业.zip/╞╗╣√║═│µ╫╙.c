#include <stdio.h>
#include <stdlib.h>
int main()
{
	int n, x, y;
	
	scanf("%d", &n);
	scanf("%d",&x);
	scanf("%d", &y);
	if ( y%x== 0) n = n - y / x;
	else if (y%x != 0)n = n - y / x - 1;
	printf("%d", n);
	return 0;
}
