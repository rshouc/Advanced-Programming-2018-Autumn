#include <stdio.h>
#include <stdlib.h>
int main()
{
	int i, n = 0, a[100] = { 0 }, b = 0, c = 0;
	double p[100] = { 0.0 };
	scanf("%d\n", &n);
	for (i = 0; i < n; i++)
	{
		scanf("%d %d %d", &a[i], &b, &c);
		p[i] = (c - b)*100.0 / b;
	}
	int t = 0;
	int j;
	for (i = 0; i < n - 1; i++)
	{
		for (j = i + 1; j < n; j++)
		{
			if (p[i] > p[j])
			{
				t = p[i];
				p[i] = p[j];
				p[j] = t;
				t = a[i];
				a[i] = a[j];
				a[j] = t;
			}
		}
	}
	double md = 0, d;
	
	for (i = 0; i < n; i++)
	{
		d = p[i + 1] - p[i];
		if (d > md)
		{
			md = d;
			j = i;
		}
	}
	printf("%d\n", n - j - 1);
	for (i = j + 1; i < n; i++)
	{
		printf("%d\n", a[i]);
	}
	printf("%d\n", j + 1);
	for (i = 0; i < j + 1; i++)
	{
		printf("%d\n", a[i]);
	}
}
