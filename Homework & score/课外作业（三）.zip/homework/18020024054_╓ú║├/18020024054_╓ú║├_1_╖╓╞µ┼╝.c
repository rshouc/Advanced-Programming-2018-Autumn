#include <stdio.h>
#include <stdlib.h>
void bubble_sort(int a[], int n)
{
    int i, j, temp;
    for (j = 0; j < n - 1; j++)
        for (i = 0; i < n - 1 - j; i++)
        {
            if(a[i] > a[i + 1])
            {
                temp = a[i];
                a[i] = a[i + 1];
                a[i + 1] = temp;
            }
        }
}
int main()
{
	int a[9],b[9],c[9];
    int i,m=0,n=0;
    for(i=0;i<=9;i++)
    scanf("%d",&a[i]);
    for(i=0;i<=9;i++)
    {
        if(a[i]%2==1)
        {
             b[m]=a[i];
             m++;
        }
        else
        {
         c[n]=a[i];
         n++;
        }
    }
    int k=m;
    bubble_sort(b,k);
    bubble_sort(c,10-k);
    for(m=0;m<k;m++)
    printf("%d ",b[m]);
    for(n=0;n<10-k;n++)
    printf("%d ",c[n]);
	system("pause");
	return 0;
}
