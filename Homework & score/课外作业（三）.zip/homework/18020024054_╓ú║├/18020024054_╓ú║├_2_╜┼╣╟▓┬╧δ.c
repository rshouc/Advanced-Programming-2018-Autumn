#include <stdio.h>
#include <stdlib.h>
int main()
{
	int a;
    int i;
    int b;
    scanf("%d",&a);
    for(i=0;i<10000000000;i++)
    {
    if(a%2==0)
      {
      b=a/2;
      printf("%d/2=%d\n",a,b);
      a=b;
      }
    else
      {
      b=a*3+1;
      printf("%d*3+1=%d\n",a,b);
      a=b;
      }
     if(a==1)
      {
       printf("End");
       break;
      }
     else
     {
     i++;
     }
    }
	system("pause");
	return 0;
}
