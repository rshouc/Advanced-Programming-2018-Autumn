#include <stdio.h>
#include <stdlib.h>
int main()
{
    int n,group[100],a[100],b[100];
    double rate[100],max,min;
    int i,j;
    double t;
    int p;
    int big=0,small=0;
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        scanf("%d %d %d",&group[i],&a[i],&b[i]);
        rate[i]=b[i]*1.0/a[i];
    }
    for(i=0;i<n-1;i++)
        for(j=0;j<n-i-1;j++)
          if(rate[j]>rate[j+1])
            {  t=rate[j];
               rate[j]=rate[j+1];
               rate[j+1]=t;
               p=group[j];
               group[j]=group[j+1];
               group[j+1]=p;
               }
    max=rate[n-1];
    min=rate[0];
    for(i=0;i<n;i++)
      {
          if(rate[i]-min>max-rate[i])   big++;
          else     small++;

      }
    printf("%d\n",big);
    for(i=small;i<n;i++) printf("%d\n",group[i]);
    printf("%d\n",small);
    for(i=0;i<small;i++)   printf("%d\n",group[i]);

	system("pause");
	return 0;
}
