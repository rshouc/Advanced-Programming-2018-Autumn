#include <stdio.h>
#include <stdlib.h>
int main()
{
	int n,high,i;
    scanf("%d",&n);
    int score[n];
    for(i=0;i<=n-1;i++)
    scanf("%d",&score[i]);
    high=score[0];
    for(i=1;i<=n-1;i++)
    {
    if(score[i]>high)high=score[i];
    }
    printf("%d",high);
	system("pause");
	return 0;
}
