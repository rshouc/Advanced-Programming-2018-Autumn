#include <stdio.h>
#include <stdlib.h>
int main()
{
	int n,x,y,k;
    scanf("%d %d %d",&n,&x,&y);
    if(y%x==0)k=n-y/x;
    else k=n-y/x-1;
    printf("%d",k);
	system("pause");
	return 0;
}
