#include <stdio.h>
#include <stdlib.h>
int main()
{
	int a;
    scanf("%d",&a);
    int b[a],i,j,zj;
    double rate[a],zhong,c[a],d[a];
    for(i=0;i<=a-1;i++) scanf("%d %lf %lf",&b[i],&c[i],&d[i]);
    for(i=0;i<=a-1;i++) rate[i]=d[i]/c[i];
    
    for(i=0;i<=a-2;i++)
    {
    for(j=0;j<=a-i-2;j++)
      {
      if(rate[j]>rate[j+1])
         {
         zhong=rate[j];
         rate[j]=rate[j+1];
         rate[j+1]=zhong;
         
         zj=b[j];
         b[j]=b[j+1];
         b[j+1]=zj;
         }
      }
    }
    double chazhimax=0;
    int flag;
    for(i=0;i<=a-2;i++)
    {
     zhong=fabs(rate[i]-rate[i+1]);
     if(zhong>chazhimax)
     {
		chazhimax=zhong;
		flag=i+1;
     }
    }
    printf("%d\n",a-flag);
    for(i=flag;i<=a-1;i++)
    {
    printf("%d\n",b[i]);
    }
    printf("%d\n",flag);
    for(i=0;i<=flag-1;i++)
    {
     printf("%d\n",b[i]);
    }
	system("pause");
	return 0;
}
